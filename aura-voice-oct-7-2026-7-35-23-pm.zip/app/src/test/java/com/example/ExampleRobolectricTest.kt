package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.gemini.AssistantAction
import com.example.data.remote.gemini.AssistantBrain
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aura Voice", appName)
    }

    @Test
    fun `test assistant local command parsing for task creation`() = runBlocking {
        val brain = AssistantBrain()
        val decision = brain.processCommand("Add task buy groceries", 0)
        assertEquals(AssistantAction.CREATE_TASK, decision.action)
        assertTrue(decision.taskTitle.contains("groceries", ignoreCase = true))
    }

    @Test
    fun `test assistant local command parsing for sms`() = runBlocking {
        val brain = AssistantBrain()
        val decision = brain.processCommand("Send SMS to John saying I will be late", 0)
        assertEquals(AssistantAction.SEND_SMS, decision.action)
        assertEquals("John", decision.recipient)
        assertTrue(decision.messageText.contains("late", ignoreCase = true))
    }
}
