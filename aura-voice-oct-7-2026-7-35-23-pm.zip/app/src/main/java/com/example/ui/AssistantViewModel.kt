package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SpeechRecognizerHelper
import com.example.audio.SpeechUiState
import com.example.audio.TextToSpeechHelper
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationMessageEntity
import com.example.data.local.TaskEntity
import com.example.data.remote.gemini.AssistantAction
import com.example.data.remote.gemini.AssistantBrain
import com.example.data.remote.gemini.AssistantDecision
import com.example.data.repository.AssistantRepository
import com.example.ui.components.AssistantVisualState
import com.example.util.MessagingHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiEvent {
    data class ShowToast(val message: String) : UiEvent
    data class OpenSms(val recipient: String, val message: String) : UiEvent
    data class OpenWhatsApp(val recipient: String, val message: String) : UiEvent
}

enum class AppScreen {
    ASSISTANT,
    TASKS,
    QUICK_ACTIONS,
    SETTINGS
}

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = AssistantRepository(database.taskDao(), database.conversationDao())
    private val brain = AssistantBrain()

    val speechHelper = SpeechRecognizerHelper(application) { recognizedText ->
        processUserInput(recognizedText)
    }

    val ttsHelper = TextToSpeechHelper(application)

    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTasks: StateFlow<List<TaskEntity>> = repository.pendingTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversationHistory: StateFlow<List<ConversationMessageEntity>> = repository.conversationHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentScreen = MutableStateFlow(AppScreen.ASSISTANT)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _autoSpeakEnabled = MutableStateFlow(true)
    val autoSpeakEnabled: StateFlow<Boolean> = _autoSpeakEnabled.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _speechPitch = MutableStateFlow(1.0f)
    val speechPitch: StateFlow<Float> = _speechPitch.asStateFlow()

    private val _uiEvents = MutableSharedFlow<UiEvent>()
    val uiEvents: SharedFlow<UiEvent> = _uiEvents.asSharedFlow()

    private val _lastDecision = MutableStateFlow<AssistantDecision?>(null)
    val lastDecision: StateFlow<AssistantDecision?> = _lastDecision.asStateFlow()

    // Combined visual state for the waveform and mic button
    val visualState: StateFlow<AssistantVisualState> = MutableStateFlow(AssistantVisualState.IDLE)

    init {
        // Collect TTS and Speech states to keep visual state in sync
        viewModelScope.launch {
            launch {
                speechHelper.uiState.collect { speechState ->
                    updateVisualState()
                }
            }
            launch {
                ttsHelper.isSpeaking.collect { isSpeaking ->
                    updateVisualState()
                }
            }
            launch {
                _isProcessing.collect {
                    updateVisualState()
                }
            }
        }
    }

    private fun updateVisualState() {
        val sState = speechHelper.uiState.value
        val speaking = ttsHelper.isSpeaking.value
        val processing = _isProcessing.value

        val state = when {
            speaking -> AssistantVisualState.SPEAKING
            processing -> AssistantVisualState.PROCESSING
            sState is SpeechUiState.Listening -> AssistantVisualState.LISTENING
            else -> AssistantVisualState.IDLE
        }
        (visualState as MutableStateFlow).value = state
    }

    fun setScreen(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun toggleListening() {
        if (ttsHelper.isSpeaking.value) {
            ttsHelper.stop()
            return
        }

        if (speechHelper.uiState.value is SpeechUiState.Listening) {
            speechHelper.stopListening()
        } else {
            speechHelper.startListening()
        }
    }

    fun processUserInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return

        speechHelper.stopListening()

        viewModelScope.launch {
            // Save user message
            repository.addMessage(
                ConversationMessageEntity(
                    sender = "USER",
                    text = trimmed,
                    actionType = "NONE"
                )
            )

            _isProcessing.value = true

            val taskCount = pendingTasks.value.size
            val decision = brain.processCommand(trimmed, taskCount)
            _lastDecision.value = decision

            // Execute local action
            when (decision.action) {
                AssistantAction.CREATE_TASK -> {
                    if (decision.taskTitle.isNotBlank()) {
                        repository.insertTask(
                            TaskEntity(
                                title = decision.taskTitle,
                                priority = decision.taskPriority,
                                category = decision.taskCategory
                            )
                        )
                    }
                }
                AssistantAction.CLEAR_COMPLETED -> {
                    repository.clearCompletedTasks()
                }
                AssistantAction.SEND_SMS -> {
                    // Pre-fill / ready action
                }
                AssistantAction.SEND_WHATSAPP -> {
                    // Pre-fill / ready action
                }
                else -> {}
            }

            // Save assistant message
            repository.addMessage(
                ConversationMessageEntity(
                    sender = "ASSISTANT",
                    text = decision.spokenReply,
                    actionType = when (decision.action) {
                        AssistantAction.SEND_SMS -> "SMS"
                        AssistantAction.SEND_WHATSAPP -> "WHATSAPP"
                        AssistantAction.CREATE_TASK -> "TASK"
                        else -> "NONE"
                    },
                    actionRecipient = decision.recipient,
                    actionPayload = if (decision.action == AssistantAction.CREATE_TASK) {
                        decision.taskTitle
                    } else decision.messageText
                )
            )

            _isProcessing.value = false

            // Auto-speak response if enabled
            if (_autoSpeakEnabled.value && decision.spokenReply.isNotBlank()) {
                ttsHelper.speak(decision.spokenReply)
            }
        }
    }

    fun executeSms(recipient: String, message: String) {
        viewModelScope.launch {
            val success = MessagingHelper.sendSms(getApplication(), recipient, message)
            if (!success) {
                _uiEvents.emit(UiEvent.ShowToast("Unable to send SMS directly."))
            }
        }
    }

    fun executeWhatsApp(recipient: String, message: String) {
        viewModelScope.launch {
            val success = MessagingHelper.sendWhatsApp(getApplication(), recipient, message)
            if (!success) {
                _uiEvents.emit(UiEvent.ShowToast("WhatsApp is not installed or available."))
            }
        }
    }

    fun addTask(title: String, priority: String = "MEDIUM", category: String = "Personal") {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertTask(
                TaskEntity(
                    title = title.trim(),
                    priority = priority,
                    category = category
                )
            )
            val msg = "Added task: ${title.trim()}"
            if (_autoSpeakEnabled.value) {
                ttsHelper.speak(msg)
            }
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(task.id, !task.isCompleted)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun clearCompletedTasks() {
        viewModelScope.launch {
            repository.clearCompletedTasks()
        }
    }

    fun clearConversation() {
        viewModelScope.launch {
            repository.clearConversation()
            ttsHelper.stop()
        }
    }

    fun setSpeechRate(rate: Float) {
        _speechRate.value = rate
        ttsHelper.setSpeechRate(rate)
    }

    fun setSpeechPitch(pitch: Float) {
        _speechPitch.value = pitch
        ttsHelper.setPitch(pitch)
    }

    fun setAutoSpeakEnabled(enabled: Boolean) {
        _autoSpeakEnabled.value = enabled
        if (!enabled) {
            ttsHelper.stop()
        }
    }

    fun speakText(text: String) {
        ttsHelper.speak(text)
    }

    fun stopSpeaking() {
        ttsHelper.stop()
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.destroy()
        ttsHelper.shutdown()
    }
}
