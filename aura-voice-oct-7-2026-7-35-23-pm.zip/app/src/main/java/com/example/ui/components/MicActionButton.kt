package com.example.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CoralWarning
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun MicActionButton(
    visualState: AssistantVisualState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isListening = visualState == AssistantVisualState.LISTENING
    val isSpeaking = visualState == AssistantVisualState.SPEAKING
    val isProcessing = visualState == AssistantVisualState.PROCESSING

    val infiniteTransition = rememberInfiniteTransition(label = "RadarRing")

    val radarScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarScale"
    )

    val radarAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarAlpha"
    )

    val buttonScale = remember { Animatable(1f) }
    LaunchedEffect(isListening) {
        if (isListening) {
            buttonScale.animateTo(1.08f, tween(200))
        } else {
            buttonScale.animateTo(1f, tween(200))
        }
    }

    val buttonColor by animateColorAsState(
        targetValue = when {
            isListening -> CyberCyan
            isProcessing -> ElectricViolet
            isSpeaking -> CoralWarning
            else -> ElectricViolet
        },
        label = "ButtonColor"
    )

    fun triggerVibration() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(90.dp)
        ) {
            // Pulsing Radar Rings when active
            if (isListening || isSpeaking || isProcessing) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .scale(radarScale)
                        .clip(CircleShape)
                        .background(buttonColor.copy(alpha = radarAlpha))
                )
            }

            // Core Glow Ring
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(buttonColor.copy(alpha = 0.25f))
            )

            // Primary Interactive Mic Circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(68.dp)
                    .scale(buttonScale.value)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(buttonColor, buttonColor.copy(alpha = 0.85f))
                        )
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        triggerVibration()
                        onClick()
                    }
                    .testTag("mic_action_button")
            ) {
                Icon(
                    imageVector = when {
                        isSpeaking -> Icons.Default.Stop
                        isListening -> Icons.Default.Mic
                        isProcessing -> Icons.Default.Mic
                        else -> Icons.Default.Mic
                    },
                    contentDescription = when {
                        isSpeaking -> "Stop Speaking"
                        isListening -> "Stop Listening"
                        else -> "Start Listening"
                    },
                    tint = if (isListening) Color.Black else Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = when {
                isListening -> "Listening... Tap to stop"
                isProcessing -> "Aura is thinking..."
                isSpeaking -> "Speaking... Tap to interrupt"
                else -> "Tap to Speak"
            },
            style = MaterialTheme.typography.bodySmall,
            color = when {
                isListening -> CyberCyan
                isSpeaking -> CoralWarning
                isProcessing -> ElectricViolet
                else -> TextSecondary
            },
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp
        )
    }
}
