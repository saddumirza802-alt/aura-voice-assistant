package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF002128),
    primaryContainer = CyberCyanDark,
    onPrimaryContainer = Color(0xFF99F6FF),
    secondary = ElectricViolet,
    onSecondary = Color(0xFF1E0A45),
    secondaryContainer = ElectricVioletDark,
    onSecondaryContainer = Color(0xFFDDD6FE),
    tertiary = MintNeon,
    onTertiary = Color(0xFF012B1E),
    tertiaryContainer = Color(0xFF065F46),
    onTertiaryContainer = Color(0xFFA7F3D0),
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = Color(0xFF334155),
    error = CoralWarning,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Voice assistant default dark theme
    dynamicColor: Boolean = false, // Keep tailored dark cyber aesthetic
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
