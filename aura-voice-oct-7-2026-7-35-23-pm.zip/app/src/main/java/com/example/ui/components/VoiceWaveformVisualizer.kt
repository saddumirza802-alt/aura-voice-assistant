package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanGlow
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.ElectricVioletGlow
import com.example.ui.theme.MintNeon
import kotlin.math.PI
import kotlin.math.sin

enum class AssistantVisualState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

@Composable
fun VoiceWaveformVisualizer(
    visualState: AssistantVisualState,
    audioLevel: Float, // 0.0 to 1.0
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "WaveAnimation")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (visualState) {
                    AssistantVisualState.PROCESSING -> 1200
                    AssistantVisualState.LISTENING -> 1600
                    AssistantVisualState.SPEAKING -> 1800
                    AssistantVisualState.IDLE -> 3500
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "Phase"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // Smooth dampening for audio level
    val smoothedAmplitude = remember { Animatable(0.1f) }
    LaunchedEffect(audioLevel, visualState) {
        val target = when (visualState) {
            AssistantVisualState.IDLE -> 0.12f
            AssistantVisualState.LISTENING -> (0.25f + audioLevel * 0.75f).coerceIn(0.2f, 1f)
            AssistantVisualState.PROCESSING -> 0.45f
            AssistantVisualState.SPEAKING -> 0.65f + (audioLevel * 0.35f)
        }
        smoothedAmplitude.animateTo(
            targetValue = target,
            animationSpec = tween(durationMillis = 120, easing = LinearEasing)
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f
            val amp = smoothedAmplitude.value * (height * 0.38f)

            // 1. Center Glowing Ambient Aura
            val glowColor = when (visualState) {
                AssistantVisualState.IDLE -> ElectricVioletGlow
                AssistantVisualState.LISTENING -> CyberCyanGlow
                AssistantVisualState.PROCESSING -> Color(0x448B5CF6)
                AssistantVisualState.SPEAKING -> Color(0x4400E5FF)
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glowColor, Color.Transparent),
                    center = Offset(width / 2f, centerY),
                    radius = (width * 0.35f) * pulseScale
                ),
                radius = (width * 0.35f) * pulseScale,
                center = Offset(width / 2f, centerY)
            )

            // 2. Frequency Equalizer Bars in center
            val barCount = 28
            val barSpacing = width / (barCount + 1)
            for (i in 0 until barCount) {
                val x = barSpacing * (i + 1)
                val distanceFromCenter = kotlin.math.abs(i - barCount / 2f) / (barCount / 2f)
                val envelope = 1f - (distanceFromCenter * distanceFromCenter)

                val barWave = sin(phase * 2f + (i * 0.45f))
                val barHeight = (amp * 1.1f * envelope * (0.3f + 0.7f * kotlin.math.abs(barWave)))
                    .coerceAtLeast(4f)

                val barColor = if (i % 2 == 0) CyberCyan else ElectricViolet

                drawLine(
                    color = barColor.copy(alpha = 0.5f + 0.5f * envelope),
                    start = Offset(x, centerY - barHeight / 2f),
                    end = Offset(x, centerY + barHeight / 2f),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 3. Primary Sine Wave (Cyber Cyan)
            val path1 = Path()
            val points1 = 60
            for (i in 0..points1) {
                val progress = i / points1.toFloat()
                val x = progress * width
                // Taper at the edges so wave blends seamlessly
                val window = sin(progress * PI.toFloat()).toFloat()
                val y = centerY + sin(phase + progress * 4f * PI.toFloat()) * amp * window
                if (i == 0) path1.moveTo(x, y) else path1.lineTo(x, y)
            }
            drawPath(
                path = path1,
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, CyberCyan, MintNeon, CyberCyan, Color.Transparent)
                ),
                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // 4. Secondary Counter Sine Wave (Electric Violet)
            val path2 = Path()
            for (i in 0..points1) {
                val progress = i / points1.toFloat()
                val x = progress * width
                val window = sin(progress * PI.toFloat()).toFloat()
                val y = centerY + sin(-phase * 1.3f + progress * 3.5f * PI.toFloat()) * (amp * 0.75f) * window
                if (i == 0) path2.moveTo(x, y) else path2.lineTo(x, y)
            }
            drawPath(
                path = path2,
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, ElectricViolet, CyberCyan, ElectricViolet, Color.Transparent)
                ),
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // 5. Processing Accent Ring or Ambient Glow
            if (visualState == AssistantVisualState.PROCESSING) {
                drawCircle(
                    color = CyberCyan.copy(alpha = 0.6f),
                    radius = 28.dp.toPx() * pulseScale,
                    center = Offset(width / 2f, centerY),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}
