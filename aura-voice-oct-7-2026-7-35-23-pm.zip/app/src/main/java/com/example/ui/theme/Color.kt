package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Dark Theme Palette
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111726)
val DarkSurfaceVariant = Color(0xFF1B2234)
val DarkSurfaceElevated = Color(0xFF232D42)
val DarkBorder = Color(0xFF2B3752)

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF006D7B)
val CyberCyanGlow = Color(0x3300E5FF)

val ElectricViolet = Color(0xFF8B5CF6)
val ElectricVioletDark = Color(0xFF4C1D95)
val ElectricVioletGlow = Color(0x338B5CF6)

val MintNeon = Color(0xFF10B981)
val CoralWarning = Color(0xFFFF5252)
val AmberAccent = Color(0xFFFBBF24)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
