package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast

object MessagingHelper {

    fun sendSms(context: Context, recipient: String, message: String): Boolean {
        return try {
            val cleanRecipient = recipient.replace(Regex("[^0-9+]"), "")
            val uri = if (cleanRecipient.isNotEmpty()) {
                Uri.parse("smsto:$cleanRecipient")
            } else {
                Uri.parse("smsto:")
            }

            val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", message)
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(smsIntent)
            true
        } catch (e: Exception) {
            try {
                // Fallback to generic ACTION_VIEW
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("sms:${recipient.replace(Regex("[^0-9+]"), "")}")
                    putExtra("sms_body", message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } catch (fallbackError: Exception) {
                Toast.makeText(context, "Could not open SMS application.", Toast.LENGTH_SHORT).show()
                false
            }
        }
    }

    fun isWhatsAppInstalled(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES)
            true
        } catch (e: Exception) {
            try {
                val pm = context.packageManager
                pm.getPackageInfo("com.whatsapp.w4b", PackageManager.GET_ACTIVITIES)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    fun sendWhatsApp(context: Context, phoneOrName: String, message: String): Boolean {
        val cleanPhone = phoneOrName.replace(Regex("[^0-9+]"), "")
        val hasDigits = cleanPhone.length >= 6

        // 1. Direct phone link if number is provided
        if (hasDigits) {
            try {
                val formattedPhone = if (!cleanPhone.startsWith("+") && cleanPhone.length == 10) {
                    "+1$cleanPhone" // fallback international prefix if 10 digits
                } else cleanPhone

                val encodedText = Uri.encode(message)
                val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedText"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                // Fallback to direct app intent
            }
        }

        // 2. Direct package intent if WhatsApp is installed
        if (isWhatsAppInstalled(context)) {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    setPackage("com.whatsapp")
                    putExtra(Intent.EXTRA_TEXT, message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                // proceed to browser link
            }
        }

        // 3. Fallback to web link or generic share intent
        return try {
            val encodedText = Uri.encode(message)
            val url = if (hasDigits) {
                "https://wa.me/${cleanPhone.replace("+", "")}?text=$encodedText"
            } else {
                "https://api.whatsapp.com/send?text=$encodedText"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // General share fallback
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Send message via"))
            true
        }
    }
}
