package com.example.data.remote.gemini

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AssistantBrain {

    private val systemPrompt = """
        You are Aura, an advanced voice assistant. Analyze the user's voice command and return a JSON object with:
        {
          "spokenReply": "Concise, friendly, spoken answer or status confirmation in 1-2 sentences suitable for text-to-speech",
          "action": "GENERAL_QA" | "SEND_SMS" | "SEND_WHATSAPP" | "CREATE_TASK" | "LIST_TASKS" | "COMPLETE_TASK" | "CLEAR_COMPLETED",
          "recipient": "Contact name or phone number if sending a message, otherwise empty",
          "message": "The message body to send via SMS or WhatsApp, otherwise empty",
          "taskTitle": "The task or reminder title to create, otherwise empty",
          "taskPriority": "HIGH" | "MEDIUM" | "LOW",
          "taskCategory": "Work" | "Personal" | "Reminder" | "Shopping"
        }
        Examples:
        - "Send a message to John saying I'll be there in 5 minutes":
          action="SEND_SMS", recipient="John", message="I'll be there in 5 minutes", spokenReply="Preparing an SMS to John saying: I'll be there in 5 minutes."
        - "Send WhatsApp to Mom saying I arrived safely":
          action="SEND_WHATSAPP", recipient="Mom", message="I arrived safely", spokenReply="Opening WhatsApp to send your message to Mom."
        - "Remind me to buy groceries tomorrow":
          action="CREATE_TASK", taskTitle="Buy groceries", taskCategory="Shopping", spokenReply="I've added 'Buy groceries' to your to-do list."
        - "Add task finish presentation with high priority":
          action="CREATE_TASK", taskTitle="Finish presentation", taskPriority="HIGH", taskCategory="Work", spokenReply="Added high priority task: Finish presentation."
        - "What is the capital of France?":
          action="GENERAL_QA", spokenReply="The capital of France is Paris."
    """.trimIndent()

    suspend fun processCommand(userPrompt: String, existingTasksCount: Int): AssistantDecision =
        withContext(Dispatchers.IO) {
            val apiKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (e: Throwable) {
                ""
            }

            // If a valid key exists and is not the template placeholder, call Gemini 3.5 Flash
            if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                try {
                    val request = GeminiRequest(
                        contents = listOf(
                            GeminiContent(
                                role = "user",
                                parts = listOf(GeminiPart(text = userPrompt))
                            )
                        ),
                        generationConfig = GeminiGenerationConfig(
                            temperature = 0.3f,
                            responseMimeType = "application/json"
                        ),
                        systemInstruction = GeminiContent(
                            parts = listOf(GeminiPart(text = systemPrompt))
                        )
                    )

                    val response = RetrofitClient.apiService.generateContent(apiKey, request)
                    val rawText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!rawText.isNullOrBlank()) {
                        val decision = parseJsonResponse(rawText)
                        if (decision != null) {
                            return@withContext decision
                        }
                    }
                } catch (e: Exception) {
                    Log.w("AssistantBrain", "Gemini API error, falling back to local reasoning: ${e.message}")
                }
            }

            // Fallback: Smart local rule-based engine
            return@withContext parseWithLocalIntelligence(userPrompt, existingTasksCount)
        }

    private fun parseJsonResponse(rawText: String): AssistantDecision? {
        return try {
            val cleanJson = rawText.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val json = JSONObject(cleanJson)
            val spokenReply = json.optString("spokenReply", "I'm on it.")
            val actionStr = json.optString("action", "GENERAL_QA").uppercase()
            val recipient = json.optString("recipient", "")
            val message = json.optString("message", "")
            val taskTitle = json.optString("taskTitle", "")
            val priority = json.optString("taskPriority", "MEDIUM").uppercase()
            val category = json.optString("taskCategory", "Personal")

            val action = when (actionStr) {
                "SEND_SMS" -> AssistantAction.SEND_SMS
                "SEND_WHATSAPP" -> AssistantAction.SEND_WHATSAPP
                "CREATE_TASK" -> AssistantAction.CREATE_TASK
                "LIST_TASKS" -> AssistantAction.LIST_TASKS
                "COMPLETE_TASK" -> AssistantAction.COMPLETE_TASK
                "CLEAR_COMPLETED" -> AssistantAction.CLEAR_COMPLETED
                else -> AssistantAction.GENERAL_QA
            }

            AssistantDecision(
                spokenReply = spokenReply,
                action = action,
                recipient = recipient,
                messageText = message,
                taskTitle = taskTitle,
                taskPriority = priority,
                taskCategory = category
            )
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Failed to parse JSON response: ${e.message}")
            null
        }
    }

    private fun parseWithLocalIntelligence(input: String, existingTasksCount: Int): AssistantDecision {
        val lower = input.lowercase().trim()

        // 1. WhatsApp matching
        val whatsappPattern = Regex(
            """(?:send\s+)?whatsapp(?:\s+message)?\s+(?:to\s+)?([a-zA-Z0-9\+\s]+?)(?:\s+(?:saying|that|with message|:)\s+(.+)|$)""",
            RegexOption.IGNORE_CASE
        )
        val waMatch = whatsappPattern.find(input)
        if (waMatch != null || lower.contains("whatsapp")) {
            var recipient = waMatch?.groupValues?.getOrNull(1)?.trim() ?: ""
            var message = waMatch?.groupValues?.getOrNull(2)?.trim() ?: ""

            if (recipient.isBlank() && lower.contains("to ")) {
                val afterTo = input.substringAfter("to ").trim()
                recipient = afterTo.substringBefore(" saying").substringBefore(" that").substringBefore(":")
                message = if (afterTo.contains("saying ")) afterTo.substringAfter("saying ") else ""
            }

            if (recipient.equals("whatsapp", ignoreCase = true)) recipient = ""

            return AssistantDecision(
                spokenReply = if (message.isNotBlank()) {
                    "Preparing WhatsApp message to ${recipient.ifEmpty { "recipient" }}: $message"
                } else {
                    "Opening WhatsApp for ${recipient.ifEmpty { "your contact" }}."
                },
                action = AssistantAction.SEND_WHATSAPP,
                recipient = recipient,
                messageText = message
            )
        }

        // 2. SMS / Text Message matching
        val smsPattern = Regex(
            """(?:send\s+(?:a\s+)?(?:sms|message|text)\s+to\s+)([a-zA-Z0-9\+\s]+?)(?:\s+(?:saying|that|:)\s+(.+)|$)""",
            RegexOption.IGNORE_CASE
        )
        val smsMatch = smsPattern.find(input)
        if (smsMatch != null || (lower.startsWith("send message") || lower.startsWith("send sms") || lower.startsWith("text "))) {
            var recipient = smsMatch?.groupValues?.getOrNull(1)?.trim() ?: ""
            var message = smsMatch?.groupValues?.getOrNull(2)?.trim() ?: ""

            if (recipient.isBlank()) {
                if (lower.startsWith("text ")) {
                    val afterText = input.removePrefix("text ").removePrefix("Text ").trim()
                    recipient = afterText.substringBefore(" saying").substringBefore(" that").substringBefore(":")
                    message = if (afterText.contains("saying ")) afterText.substringAfter("saying ") else ""
                } else if (lower.contains(" to ")) {
                    val afterTo = input.substringAfter(" to ").trim()
                    recipient = afterTo.substringBefore(" saying").substringBefore(" that").substringBefore(":")
                    message = if (afterTo.contains("saying ")) afterTo.substringAfter("saying ") else ""
                }
            }

            return AssistantDecision(
                spokenReply = if (message.isNotBlank()) {
                    "Composing SMS to ${recipient.ifEmpty { "recipient" }}: $message"
                } else {
                    "Composing text message to ${recipient.ifEmpty { "recipient" }}."
                },
                action = AssistantAction.SEND_SMS,
                recipient = recipient,
                messageText = message
            )
        }

        // 3. Task / To-do / Reminder creation
        val taskCreatePattern = Regex(
            """(?:add\s+(?:a\s+)?(?:task|todo|to-do|reminder|item)|remind\s+me\s+to|create\s+(?:a\s+)?(?:task|reminder))\s+(.+)""",
            RegexOption.IGNORE_CASE
        )
        val taskMatch = taskCreatePattern.find(input)
        if (taskMatch != null || lower.startsWith("remind me ") || lower.startsWith("todo:") || lower.startsWith("task:")) {
            var title = taskMatch?.groupValues?.getOrNull(1)?.trim() ?: ""
            if (title.isBlank()) {
                title = input.removePrefix("remind me to ").removePrefix("Remind me to ")
                    .removePrefix("remind me ").removePrefix("Remind me ")
                    .removePrefix("todo:").removePrefix("task:").trim()
            }

            val isHighPriority = lower.contains("urgent") || lower.contains("important") || lower.contains("high priority")
            val priority = if (isHighPriority) "HIGH" else "MEDIUM"
            val category = when {
                lower.contains("buy") || lower.contains("shop") || lower.contains("grocery") -> "Shopping"
                lower.contains("meeting") || lower.contains("email") || lower.contains("report") || lower.contains("client") -> "Work"
                lower.contains("remind") || lower.contains("call") -> "Reminder"
                else -> "Personal"
            }

            return AssistantDecision(
                spokenReply = "I have created the task: $title",
                action = AssistantAction.CREATE_TASK,
                taskTitle = title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() },
                taskPriority = priority,
                taskCategory = category
            )
        }

        // 4. List Tasks
        if (lower.contains("show my tasks") || lower.contains("list my tasks") || lower.contains("what are my tasks") || lower.contains("what's on my to-do")) {
            return AssistantDecision(
                spokenReply = if (existingTasksCount > 0) {
                    "You have $existingTasksCount active task${if (existingTasksCount == 1) "" else "s"} on your list."
                } else {
                    "Your to-do list is currently empty. You are all caught up!"
                },
                action = AssistantAction.LIST_TASKS
            )
        }

        // 5. Clear / Complete
        if (lower.contains("clear completed") || lower.contains("delete completed")) {
            return AssistantDecision(
                spokenReply = "Clearing all completed tasks from your list.",
                action = AssistantAction.CLEAR_COMPLETED
            )
        }

        // 6. Time and Date inquiries
        if (lower.contains("what time") || lower.contains("current time") || lower.contains("tell me the time")) {
            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return AssistantDecision(
                spokenReply = "It is currently $time.",
                action = AssistantAction.GENERAL_QA
            )
        }

        if (lower.contains("what day") || lower.contains("what date") || lower.contains("today's date")) {
            val date = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
            return AssistantDecision(
                spokenReply = "Today is $date.",
                action = AssistantAction.GENERAL_QA
            )
        }

        // 7. Greetings & Personal Info
        if (lower.contains("hello") || lower.contains("hi aura") || lower.startsWith("hi") || lower.startsWith("hey")) {
            return AssistantDecision(
                spokenReply = "Hello! I'm Aura, your personal voice assistant. How can I assist you today?",
                action = AssistantAction.GENERAL_QA
            )
        }

        if (lower.contains("who are you") || lower.contains("what can you do")) {
            return AssistantDecision(
                spokenReply = "I'm Aura, your voice assistant. I can send SMS or WhatsApp messages, organize your to-do lists and reminders, and answer your questions.",
                action = AssistantAction.GENERAL_QA
            )
        }

        // Default response
        return AssistantDecision(
            spokenReply = "I heard: \"$input\". You can ask me to send messages, add tasks, or answer questions.",
            action = AssistantAction.GENERAL_QA
        )
    }
}
