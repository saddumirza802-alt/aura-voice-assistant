package com.example.data.repository

import com.example.data.local.ConversationDao
import com.example.data.local.ConversationMessageEntity
import com.example.data.local.TaskDao
import com.example.data.local.TaskEntity
import kotlinx.coroutines.flow.Flow

class AssistantRepository(
    private val taskDao: TaskDao,
    private val conversationDao: ConversationDao
) {
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()
    val pendingTasks: Flow<List<TaskEntity>> = taskDao.getPendingTasks()
    val conversationHistory: Flow<List<ConversationMessageEntity>> = conversationDao.getAllMessages()

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.updateTask(task)

    suspend fun toggleTaskCompleted(id: Long, completed: Boolean) =
        taskDao.setTaskCompleted(id, completed)

    suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

    suspend fun deleteTaskById(id: Long) = taskDao.deleteTaskById(id)

    suspend fun clearCompletedTasks() = taskDao.clearCompletedTasks()

    suspend fun addMessage(message: ConversationMessageEntity): Long =
        conversationDao.insertMessage(message)

    suspend fun clearConversation() = conversationDao.clearAllMessages()
}
