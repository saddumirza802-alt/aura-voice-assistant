package com.example.data.remote.gemini

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig? = null,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null
)

data class AssistantDecision(
    val spokenReply: String,
    val action: AssistantAction = AssistantAction.GENERAL_QA,
    val recipient: String = "",
    val messageText: String = "",
    val taskTitle: String = "",
    val taskPriority: String = "MEDIUM",
    val taskCategory: String = "Personal"
)

enum class AssistantAction {
    GENERAL_QA,
    SEND_SMS,
    SEND_WHATSAPP,
    CREATE_TASK,
    LIST_TASKS,
    COMPLETE_TASK,
    CLEAR_COMPLETED
}
