package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversation_messages")
data class ConversationMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "USER" or "ASSISTANT"
    val text: String,
    val actionType: String = "NONE", // "SMS", "WHATSAPP", "TASK", "NONE"
    val actionRecipient: String = "",
    val actionPayload: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
